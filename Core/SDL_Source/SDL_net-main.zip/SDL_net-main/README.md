# SDL_net 3.0

The latest version of this library is available from GitHub:

https://github.com/libsdl-org/SDL_net/releases

This is a portable network library for use with SDL. It's goal is to
simplify the use of the usual socket interfaces and use SDL infrastructure
to handle some portability things (such as threading and reporting
errors).

It is available under the zlib license, found in the file LICENSE.txt.
The API can be found in the file SDL_net.h and online at https://wiki.libsdl.org/SDL3_net
This library supports most platforms that offer both SDL3 and networking.

This is a work in progress!

Enjoy!


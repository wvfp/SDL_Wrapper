A complete game of Snake, written in SDL.

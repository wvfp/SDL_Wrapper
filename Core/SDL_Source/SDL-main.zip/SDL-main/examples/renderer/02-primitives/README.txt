This example creates an SDL window and renderer, and then draws some lines,
rectangles and points to it every frame.


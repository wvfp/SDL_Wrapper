#include <SDL3/SDL.h>
#include <SDL3/SDL_test.h>


int main(int argc, char *argv[]) {
    SDLTest_CommonState state;
    SDLTest_CommonDefaultArgs(&state, argc, argv);
    return 0;
}
